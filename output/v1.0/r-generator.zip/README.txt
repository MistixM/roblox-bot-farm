Thank you for trust :)

---
How to change the API key of capsolver extension?
---
First of all, make sure that you have enough funds in your account. To change API key go to "extension/assets/config.js". Open it and you'll see api_key variable. Please insert new to change API. Please note that removal of the API key will disable captcha solving

---
Some important things to know
---
= DO NOT delete the Account folder. This folder contains all account data. Please remove it only at your own risk.
= Don't call account generation too often it may cause 429 error code - too many requests and it will unable to create "valid" accounts

That's all. Please feel free to DM me if you have any updates for your program or any help. I will try to help you and give detailed feedback